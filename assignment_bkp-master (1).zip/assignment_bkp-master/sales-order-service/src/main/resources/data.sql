insert into customer_sos(cust_id,cust_email,cust_first_name,cust_last_name) values (101,'aaa@test.com','AAA','BBB');
insert into customer_sos(cust_id,cust_email,cust_first_name,cust_last_name) values (102,'bbb@test.com','BBB','DDD');
insert into customer_sos(cust_id,cust_email,cust_first_name,cust_last_name) values (103,'ccc@test.com','CCC','FFF');