package com.sg.microservices.assignment.salesorder;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EventConsumerConfiguration {

  @Bean
  public TopicExchange eventExchange() {
    return new TopicExchange("eventExchange");
  }

  @Bean
  public Queue queue() {
    return new Queue("salesOrderServiceQueue");
  }

  @Bean
  public Binding binding(Queue queue, TopicExchange eventExchange) {
    return BindingBuilder
            .bind(queue)
            .to(eventExchange)
            .with("customer.*");
  }

  @Bean
  public EventConsumer eventReceiver() {
    return new EventConsumer();
  }

}
