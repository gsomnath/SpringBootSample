package com.sg.microservices.assignment.salesorder;


import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Sales_Order")
public class SalesOrder {
	
	@Id
	@GeneratedValue
	@Column(name="id")
	private Long salesOrderId;
		
	@Column(name="order_date")
	private Date orderDate;
	
	@Column(name="cust_id")
	private Long custId;
	
	public Long getCustId() {
		return custId;
	}

	public void setCustId(Long custId) {
		this.custId = custId;
	}

	@Column(name="order_desc")
	private String orderDesc;
	
	@Column(name="total_price")
	private Float totalPrice;
	
	@OneToMany(mappedBy="salesOrder",cascade=CascadeType.ALL)
	private List<OrderLineItem> lstOrdeLineItem;

	public SalesOrder(Long salesOrderId, Date orderDate, Long custId, String orderDesc, Float totalPrice,
			List<OrderLineItem> lstOrdeLineItem) {
		super();
		this.salesOrderId = salesOrderId;
		this.orderDate = orderDate;
		this.custId = custId;
		this.orderDesc = orderDesc;
		this.totalPrice = totalPrice;
		this.lstOrdeLineItem = lstOrdeLineItem;
	}
	
	public SalesOrder() {}

	public Long getSalesOrderId() {
		return salesOrderId;
	}

	public void setSalesOrderId(Long salesOrderId) {
		this.salesOrderId = salesOrderId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderDesc() {
		return orderDesc;
	}

	public void setOrderDesc(String orderDesc) {
		this.orderDesc = orderDesc;
	}

	public Float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Float totalPrice) {
		this.totalPrice = totalPrice;
	}

	public List<OrderLineItem> getLstOrdeLineItem() {
		return lstOrdeLineItem;
	}

	public void setLstOrdeLineItem(List<OrderLineItem> lstOrdeLineItem) {
		this.lstOrdeLineItem = lstOrdeLineItem;
	}
	
	
		

}
