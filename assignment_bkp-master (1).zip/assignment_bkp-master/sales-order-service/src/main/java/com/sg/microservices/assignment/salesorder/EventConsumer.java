package com.sg.microservices.assignment.salesorder;


import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EventConsumer {

	  private Logger logger = LoggerFactory.getLogger(EventConsumer.class);
	  
	  @Autowired
	  CustomerSosRepository customerSosRepository;

	  @RabbitListener(queues="salesOrderServiceQueue")
	  public void receive(String message) {
		  
		  ObjectMapper mapper = new ObjectMapper();
		  try {
			CustomerSos customerSos= mapper.readValue(message, CustomerSos.class);
			customerSosRepository.save(customerSos);
			logger.info("Data" + customerSos.getCustId());
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.info("Data1");
			logger.info("JsonParseException:", e.toString());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.info("Data2");
			logger.info("JsonMappingException:", e.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.info("Data3");
			logger.info("IOException:", e.toString());
		}
	    logger.info("Received message '{}'", message);
	  }

}