package com.sg.microservices.assignment.salesorder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Order_Line_Item")
public class OrderLineItem {
	
	@Id
	@GeneratedValue
	@Column(name="id")
	private Long orderLineItemId;
	
	@Column(name="item_name")
	private String itemName;
	
	@Column(name="item_quantity")
	private String itemQuantity;
	
	@ManyToOne
    @JoinColumn(name="order_id")
	private SalesOrder salesOrder;

	public OrderLineItem(Long orderLineItemId, String itemName, String itemQuantity, SalesOrder salesOrder) {
		super();
		this.orderLineItemId = orderLineItemId;
		this.itemName = itemName;
		this.itemQuantity = itemQuantity;
		this.salesOrder = salesOrder;
	}
	
	public OrderLineItem() {}

	public Long getOrderLineItemId() {
		return orderLineItemId;
	}

	public void setOrderLineItemId(Long orderLineItemId) {
		this.orderLineItemId = orderLineItemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(String itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public SalesOrder getSalesOrder() {
		return salesOrder;
	}

	public void setSalesOrder(SalesOrder salesOrder) {
		this.salesOrder = salesOrder;
	}
	
	
	

}
