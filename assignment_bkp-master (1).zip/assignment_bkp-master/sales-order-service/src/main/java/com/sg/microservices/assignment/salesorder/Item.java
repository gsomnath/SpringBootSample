package com.sg.microservices.assignment.salesorder;

public class Item {
	
	private Long itemId;
	private String itemName;
	private String itemDesc;
	private Float iemPrice;

	
	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public Float getIemPrice() {
		return iemPrice;
	}

	public void setIemPrice(Float iemPrice) {
		this.iemPrice = iemPrice;
	}
		
}
