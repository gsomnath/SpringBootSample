package com.sg.microservices.assignment.salesorder;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class OrdersService {
	
	@Autowired
	SalesOrderRepository salesOrderRepository;
	
	@Autowired
	CustomerSosRepository customerSosRepository;
	
	@Autowired
	Environment environment;
	
	@Autowired
	ItemService itemService;
	
	private static Logger log = LoggerFactory.getLogger(SalesOrderController.class);

	
	
	@HystrixCommand(fallbackMethod="fallBackOrders")
	public String createSalesOrder(Order order) {
		
		log.info("Started to create order !!!");
		
		String createSalesOrderRes = "";
		boolean orderStillValid = true;
		
		//Validate customer by cust_id
		boolean validCustId=customerSosRepository.exists(order.getCustomerId());
		
		if(!validCustId) {
			createSalesOrderRes = "Not a vilad customerID: "+ order.getCustomerId();
			log.info("Not a vilad customerID: "+ order.getCustomerId());
			orderStillValid=false;
		}else {
			log.info("Vilad customerID: "+ order.getCustomerId());
		}
		
		
		float total_price = 0.00f;
		List<OrderLineItem> orderLineItemList = new ArrayList<OrderLineItem>();
		
		SalesOrder salesOrder = new SalesOrder();
		
		//item validation.
		
		if(orderStillValid) {
			for(String item : order.getItems()) {
				Item tmpItem = itemService.getItemDetails(item);
				if(tmpItem == null) {
					createSalesOrderRes = "invalid item: "+ item;
					log.info("invalid item: "+ item);
					orderStillValid=false;
					break;
				}else {
					log.info("item: "+ tmpItem.getItemName());
					total_price=total_price+tmpItem.getIemPrice();
					OrderLineItem orderLineItem = new OrderLineItem();
					orderLineItem.setItemName(tmpItem.getItemName());
					orderLineItem.setItemQuantity("1");
					orderLineItem.setSalesOrder(salesOrder);
					orderLineItemList.add(orderLineItem);
				}
			}
		}
			
		//Create order
		if (orderStillValid) {
			salesOrder.setOrderDate(new Date());
			salesOrder.setCustId(order.getCustomerId());
			salesOrder.setOrderDesc(order.getOrderDescription());
			salesOrder.setTotalPrice(total_price);
			salesOrder.setLstOrdeLineItem(orderLineItemList);
			salesOrderRepository.save(salesOrder);
					
			createSalesOrderRes = "Sales order created successfully with oredreId: " + salesOrder.getSalesOrderId();
			}
		
		return(createSalesOrderRes);
	}
	
	public String fallBackOrders(Order order) {
		return "Please try after some time !!!";
		//return new Customer(CustomerConfiguration.defaultFirstName,
				//CustomerConfiguration.defaultLastName,105L, new Date());
	}

}
