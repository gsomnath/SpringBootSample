insert into item(id,name,description,price) values (1001,'1stItem','1stItem desc',100.00);
insert into item(id,name,description,price) values (1002,'2ndItem','2ndItem desc',200.00);
insert into item(id,name,description,price) values (1003,'3rdItem','3rdItem desc',300.00);