package com.sg.microservices.assignment.item;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ItemRepository extends JpaRepository<Item, Long> {
	
	//@Query("select i from Item i where i.name = ?1")
    //Item getItemDetailsByName(String itemName);
	
	@Query(value = "SELECT * FROM Item WHERE name = ?1", nativeQuery = true)
	Item getItemDetailsByName(String itemName);

}
