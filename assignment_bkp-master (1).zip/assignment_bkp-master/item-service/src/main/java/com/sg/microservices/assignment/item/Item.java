package com.sg.microservices.assignment.item;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Item {
	
	@Id
	@Column(name="id")
	private Long itemId;
	
	@Column(name="name")
	private String itemName;
	
	@Column(name="description")
	private String itemDesc;
	
	@Column(name="price")
	private Float iemPrice;

	public Item(Long itemId, String itemName, String itemDesc, Float iemPrice) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemDesc = itemDesc;
		this.iemPrice = iemPrice;
	}
	
	public Item() {}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public Float getIemPrice() {
		return iemPrice;
	}

	public void setIemPrice(Float iemPrice) {
		this.iemPrice = iemPrice;
	}
		
}
