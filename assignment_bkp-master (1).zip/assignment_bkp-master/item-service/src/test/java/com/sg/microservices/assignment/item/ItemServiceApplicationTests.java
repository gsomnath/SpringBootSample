package com.sg.microservices.assignment.item;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
