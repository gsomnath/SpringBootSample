package com.sg.microservices.assignment.eurekanaming;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaNamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
