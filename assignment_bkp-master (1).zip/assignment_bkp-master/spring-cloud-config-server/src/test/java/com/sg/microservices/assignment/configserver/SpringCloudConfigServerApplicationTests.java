package com.sg.microservices.assignment.configserver;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
