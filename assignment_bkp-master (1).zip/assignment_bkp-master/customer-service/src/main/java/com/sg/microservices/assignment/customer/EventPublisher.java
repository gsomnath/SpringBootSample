
package com.sg.microservices.assignment.customer;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class EventPublisher {

  private Logger logger = LoggerFactory.getLogger(EventPublisher.class);

  private final RabbitTemplate rabbitTemplate;

  private final TopicExchange topicExchange;

  //private int messageNumber = 0;

  
  @Autowired
  public EventPublisher(RabbitTemplate rabbitTemplate, TopicExchange topicExchange) {
    this.rabbitTemplate = rabbitTemplate;
    this.topicExchange = topicExchange;
  }

  public void sendMessage(Customer customer) {
    String routingKey =  "customer.created";
    //String message = String.format("Event no. %d of type '%s'", ++messageNumber, customer.getcustId());
    ObjectMapper mapper = new ObjectMapper();
    
    String message = "Test";
	try {
		message = mapper.writeValueAsString(customer);
	} catch (JsonProcessingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
    rabbitTemplate.convertAndSend(topicExchange.getName(), routingKey, message);
    //rabbitTemplate.send(customer.getEmail());
    logger.info("Published message '{}'", message);
  } 

}
