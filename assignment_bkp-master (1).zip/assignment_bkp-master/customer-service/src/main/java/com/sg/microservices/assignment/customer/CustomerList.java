package com.sg.microservices.assignment.customer;

import java.util.List;

public class CustomerList {
	
	private List<Customer> customerList;
	
	public List<Customer> getCustomerList() {
		return customerList;
	}

	public void setCustomerList(List<Customer> customerList) {
		this.customerList = customerList;
	}

	
}
