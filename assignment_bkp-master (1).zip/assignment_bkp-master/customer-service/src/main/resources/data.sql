insert into customer(id,email,first_name,last_name) values (101,'aaa@test.com','AAA','BBB');
insert into customer(id,email,first_name,last_name) values (102,'bbb@test.com','BBB','DDD');
insert into customer(id,email,first_name,last_name) values (103,'ccc@test.com','CCC','FFF');